#!/usr/bin/env python3

class config:
    def get_clientid(self):
        return 'vYEoWo1KwFrcqg'

    def get_useragent(self):
        return 'Yathartha'
